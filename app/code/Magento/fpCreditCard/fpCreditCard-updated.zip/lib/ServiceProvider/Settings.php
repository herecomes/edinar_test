<?php

namespace ServiceProvider;

class Settings {
  public static $shopId;
  public static $shopKey;
  public static $shopPubKey;
  
  public static $gatewayBase  = 'https://sandbox.fluidpay.com/api/';

  public static $checkoutBase = 'https://sandbox.fluidpay.com/api/';

  public static $apiBase      = 'https://sandbox.fluidpay.com/api/';

  public static $sandboxUrl   = 'https://sandbox.fluidpay.com/api/';


  public static $apiBaseUrl      = 'https://sandbox.fluidpay.com/api/';
  public static $apiKey;


}
?>
