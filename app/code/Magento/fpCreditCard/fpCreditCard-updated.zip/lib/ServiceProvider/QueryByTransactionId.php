<?php
namespace ServiceProvider;

class QueryByTransactionId extends ApiAbstract {

  protected function _buildRequestMessage() {
    return '';
  }
}
?>
