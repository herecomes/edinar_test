<?php
namespace ServiceProvider;

class ShippingAddress extends Customer{
}
?>
