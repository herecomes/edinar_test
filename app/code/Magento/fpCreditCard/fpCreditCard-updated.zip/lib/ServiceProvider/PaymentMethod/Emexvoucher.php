<?php
namespace ServiceProvider\PaymentMethod;

class Emexvoucher extends Base {
}
?>
