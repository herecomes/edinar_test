<?php
namespace ServiceProvider\PaymentMethod;

class CreditCard extends Base {
}
?>
