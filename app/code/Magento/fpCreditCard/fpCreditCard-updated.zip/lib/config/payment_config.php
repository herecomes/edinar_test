<?php
\ServiceProvider\Settings::$shopId = '';
\ServiceProvider\Settings::$shopKey = '';
\ServiceProvider\Settings::$checkoutBase = 'https://sandbox.fluidpay.com/api/';
\ServiceProvider\Settings::$gatewayBase  = 'https://sandbox.fluidpay.com/api/';


\ServiceProvider\Settings::$apiBase      = 'https://sandbox.fluidpay.com/api/';
\ServiceProvider\Settings::$apiKey;


\ServiceProvider\Settings::$sandboxUrl       = 'https://sandbox.fluidpay.com/api/';
\ServiceProvider\Settings::$apiBaseUrl       = 'https://app.fluidpay.com/api/';

?>
